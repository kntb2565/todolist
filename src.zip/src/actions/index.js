import * as types from '../constants/ActionTypes';

export const addTodo = (todo) => ({ type: types.ADDTODO, todo });